# Project on multi-threaded programming using FreeRTOS

In this project you will practice programming of parallel programs using FreeRTOS. There are two subprojects, project_A and project_B. Each subproject contains a Makefile that you can use to compile the files.

Before compiling you can execute ./setup.sh to make sure that you have all the essential tools installed to compile the code.
