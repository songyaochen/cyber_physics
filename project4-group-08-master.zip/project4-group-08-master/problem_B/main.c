#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>

#include "FreeRTOS.h"
#include "task.h"
#include "semphr.h"

#define MIN_CROSSING_DELAY 500
#define CROSSING_DELAY 1000
#define ARRIVE_DELAY 1500

xTaskHandle *batTaskHandles; // Create as a pointer since the number of bats are unknown at compile time
SemaphoreHandle_t cross_detection;
SemaphoreHandle_t gs_arrived;
SemaphoreHandle_t gn_arrived;
SemaphoreHandle_t gw_arrived;
SemaphoreHandle_t ge_arrived;

SemaphoreHandle_t gs_counter;
SemaphoreHandle_t gn_counter;
SemaphoreHandle_t gw_counter;
SemaphoreHandle_t ge_counter;
SemaphoreHandle_t cross_counter;


int *batIds;

volatile int counter = 0;

void goSouth(int batId)
{
    const TickType_t waitingToArriveDelay = (rand() % ARRIVE_DELAY) / portTICK_PERIOD_MS; // Generate a random delay 
    const TickType_t crossingDelay = (rand() % CROSSING_DELAY + MIN_CROSSING_DELAY) / portTICK_PERIOD_MS; 
    
    printf("BAT %d from North has started to run and is on its way to the crossing\n", batId);

    vTaskDelay(waitingToArriveDelay);   

    printf("BAT %d from North arrives at crossing\n", batId);
    //xSemaphoreTake(gs_arrived,portMAX_DELAY);
    //xSemaphoreTake(gw_arrived,portMAX_DELAY);
    xSemaphoreGive(gs_counter);
    while( uxSemaphoreGetCount(ge_counter)!=0 || uxSemaphoreGetCount(cross_counter)==1){
         vTaskDelay(2*crossingDelay);
    }
        xSemaphoreGive(cross_counter);
        //xSemaphoreTake(cross_detection,portMAX_DELAY);
        printf("BAT %d from North enters crossing\n", batId);
        xSemaphoreTake(gs_counter,portMAX_DELAY);

        vTaskDelay(crossingDelay);   
        printf("BAT %d from North leaving crossing\n", batId);
        xSemaphoreTake(cross_counter,portMAX_DELAY);
    //xSemaphoreTake(cross_detection,portMAX_DELAY);
        //xSemaphoreGive(cross_detection);  

    //xSemaphoreGive(gs_arrived);
   // xSemaphoreGive(gw_arrived);

    vTaskDelay(waitingToArriveDelay);
}

void goNorth(int batId)
{
    const TickType_t waitingToArriveDelay = (rand() % ARRIVE_DELAY) / portTICK_PERIOD_MS; // Generate a random delay 
    const TickType_t crossingDelay = (rand() % CROSSING_DELAY + MIN_CROSSING_DELAY) / portTICK_PERIOD_MS;
 
    printf("BAT %d from South has started to run and is on its way to the crossing\n", batId);

    vTaskDelay(waitingToArriveDelay);   
  
    printf("BAT %d from South arrives at crossing\n", batId);
    
    //xSemaphoreTake(gn_arrived,portMAX_DELAY);
    //xSemaphoreTake(ge_arrived,portMAX_DELAY);

    //xSemaphoreTake(cross_detection,portMAX_DELAY);  
    xSemaphoreGive(gn_counter);
    while(uxSemaphoreGetCount(gw_counter)!=0 || uxSemaphoreGetCount(cross_counter)==1){
          vTaskDelay(2*crossingDelay);
    }

    xSemaphoreGive(cross_counter);
    //xSemaphoreTake(cross_detection,portMAX_DELAY); 
    printf("BAT %d from South enters crossing\n", batId);
    xSemaphoreTake(gn_counter,portMAX_DELAY);

    vTaskDelay(crossingDelay);   
    printf("BAT %d from South leaving crossing\n", batId);
    xSemaphoreTake(cross_counter,portMAX_DELAY);  
    //xSemaphoreGive(cross_detection); 
    //xSemaphoreGive(gn_arrived);
    //xSemaphoreGive(ge_arrived);  

    vTaskDelay(waitingToArriveDelay);
}

void goEast(int batId)
{
    const TickType_t waitingToArriveDelay = (rand() % ARRIVE_DELAY) / portTICK_PERIOD_MS; // Generate a random delay   
    const TickType_t crossingDelay = (rand() % CROSSING_DELAY + MIN_CROSSING_DELAY) / portTICK_PERIOD_MS; 
    
    printf("BAT %d from West has started to run and is on its way to the crossing\n", batId);

    vTaskDelay(waitingToArriveDelay);   

    printf("BAT %d from West arrives at crossing\n", batId);

    //xSemaphoreTake(ge_arrived,portMAX_DELAY);
    //xSemaphoreTake(gs_arrived,portMAX_DELAY);

    //xSemaphoreTake(cross_detection,portMAX_DELAY);
    xSemaphoreGive(ge_counter);
    while(uxSemaphoreGetCount(gn_counter)!=0 || uxSemaphoreGetCount(cross_counter)==1){
         vTaskDelay(2*crossingDelay);
    }

      xSemaphoreGive(cross_counter);
      //xSemaphoreTake(cross_detection,portMAX_DELAY);
      printf("BAT %d from West enters crossing\n", batId);
      xSemaphoreTake(ge_counter,portMAX_DELAY);

      vTaskDelay(crossingDelay);   
      printf("BAT %d from West leaving crossing\n", batId);
      xSemaphoreTake(cross_counter,portMAX_DELAY);  
      //xSemaphoreGive(cross_detection);  

    //xSemaphoreGive(ge_arrived);
    //xSemaphoreGive(gs_arrived); 

    vTaskDelay(waitingToArriveDelay);
}

void goWest(int batId)
{
    const TickType_t waitingToArriveDelay = (rand() % ARRIVE_DELAY) / portTICK_PERIOD_MS; // Generate a random delay 
    const TickType_t crossingDelay = (rand() % CROSSING_DELAY + MIN_CROSSING_DELAY) / portTICK_PERIOD_MS; 
     
    printf("BAT %d from East has started to run and is on its way to the crossing\n", batId);


    vTaskDelay(waitingToArriveDelay);   

    printf("BAT %d from East arrives at crossing\n", batId);
    //xSemaphoreTake(gw_arrived,portMAX_DELAY);
    //xSemaphoreTake(gn_arrived,portMAX_DELAY);

    //xSemaphoreTake(cross_detection,portMAX_DELAY);
    xSemaphoreGive(gw_counter);
    while(uxSemaphoreGetCount(gs_counter)!=0 || uxSemaphoreGetCount(cross_counter)==1){
          vTaskDelay(2*crossingDelay);
          if(uxSemaphoreGetCount(ge_counter)!=0 && uxSemaphoreGetCount(gn_counter)!=0 && uxSemaphoreGetCount(cross_counter)==0){
                        break;
          }
    }

     xSemaphoreGive(cross_counter);
     //xSemaphoreTake(cross_detection,portMAX_DELAY);
     printf("BAT %d from East enters crossing\n", batId);
     xSemaphoreTake(gw_counter,portMAX_DELAY);

     vTaskDelay(crossingDelay);   
     printf("BAT %d from East leaving crossing\n", batId);
     xSemaphoreTake(cross_counter,portMAX_DELAY);  
     //xSemaphoreGive(cross_detection);   

    //xSemaphoreGive(gw_arrived);
    //xSemaphoreGive(gn_arrived);

    vTaskDelay(waitingToArriveDelay);
}

void batFromNorth(void *pvParameters)
{
    int batId = *(int *)pvParameters;
    
    while (1) // Repeat forever
    {
	goSouth(batId); 
	goNorth(batId);
    }
}

void batFromSouth(void *pvParameters)
{
    int batId = *(int *)pvParameters;
    
    while (1)
    {
	goNorth(batId); 
	goSouth(batId);
    }
}

void batFromEast(void *pvParameters)
{
    int batId = *(int *)pvParameters;
    
    while (1)
    {
	goWest(batId); 
	goEast(batId);
    }
}

void batFromWest(void *pvParameters)
{
    int batId = *(int *)pvParameters;
    
    while (1)
    {
	goEast(batId); 
	goWest(batId);
    }
}


int main(int argc, char **argv)
{
    int batId;
    int numberOfBats;
    cross_detection = xSemaphoreCreateMutex();
    gs_arrived = xSemaphoreCreateMutex();
    gn_arrived = xSemaphoreCreateMutex();
    gw_arrived = xSemaphoreCreateMutex();
    ge_arrived = xSemaphoreCreateMutex();

    gs_counter = xSemaphoreCreateCounting(5,0);
    gn_counter = xSemaphoreCreateCounting(5,0);
    ge_counter = xSemaphoreCreateCounting(5,0);
    gw_counter = xSemaphoreCreateCounting(5,0);
    cross_counter = xSemaphoreCreateCounting(1,0);
        
    if (argc < 2)
    {
    	printf("Argument missing, specify sequence of arrivals. Example: ./batman nsewwewn\n");
    	exit(-1);
    }
    
    char *commands = argv[1];
    numberOfBats = strlen(argv[1]);

    batTaskHandles = malloc(sizeof(xTaskHandle) * numberOfBats); // Allocate memory for the task handles
    batIds = malloc(sizeof(int) * numberOfBats); // Allocate memory for the task ids
       
    for (batId = 0; batId < numberOfBats; batId++)
    {
    	batIds[batId] = batId;
    	char currentBatDirection = (argv[1])[batId];
    	char batTaskIdentity[50];
    	
    	if (currentBatDirection == 'n')
    	{
    	    sprintf(batTaskIdentity, "Bat %d from North", batId);
      	    xTaskCreate(batFromNorth, batTaskIdentity, configMINIMAL_STACK_SIZE, (void *)&batIds[batId], 1, batTaskHandles[batId]);  
      	    printf("Created task \"Bat %d from North\"\n", batId); 	
    	}
    	else if (currentBatDirection == 's')
    	{
      	    sprintf(batTaskIdentity, "Bat %d from South", batId);
      	    xTaskCreate(batFromSouth, batTaskIdentity, configMINIMAL_STACK_SIZE, (void *)&batIds[batId], 1, batTaskHandles[batId]);  
      	    printf("Created task \"Bat %d from South\"\n", batId);   	
    	}
     	else if (currentBatDirection == 'e')
    	{
     	    sprintf(batTaskIdentity, "Bat %d from East", batId);
      	    xTaskCreate(batFromEast, batTaskIdentity, configMINIMAL_STACK_SIZE, (void *)&batIds[batId], 1, batTaskHandles[batId]);  
      	    printf("Created task \"Bat %d from East\"\n", batId);    	
    	}  
    	else if (currentBatDirection == 'w')
    	{
     	    sprintf(batTaskIdentity, "Bat %d from West", batId);
      	    xTaskCreate(batFromWest, batTaskIdentity, configMINIMAL_STACK_SIZE, (void *)&batIds[batId], 1, batTaskHandles[batId]);  
      	    printf("Created task \"Bat %d from West\"\n", batId);    	
    	}    	
    	else
    	{
     	    printf("Unknown direction: %c\n", currentBatDirection);
    	    exit(-1);   	
    	} 	

    }
    
    vTaskStartScheduler();
    while (1)
    {
    	// Do nothing
    };
 
    free(batTaskHandles); // Return memory for the task handles
    return 0;
}

