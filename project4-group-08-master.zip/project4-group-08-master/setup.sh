#!/bin/sh
sudo apt update
sudo apt install build-essential -y
sudo apt install gcc-multilib -y
